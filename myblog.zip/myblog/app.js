var express = require("express"),
    app= express(),
    bodyparser =require("body-parser"),
    mongoose =require("mongoose"),
    methodoverride = require("method-override");
//appconfig
app.set("view engine","ejs");
app.use(bodyparser.urlencoded({extended:true}));
app.use(express.static("public"));
app.use(methodoverride("_method"));
mongoose.connect('mongodb+srv://user:12345@cluster0.0bz4o.mongodb.net/blogapp?retryWrites=true&w=majority');
//mongoose.connect('mongodb://localhost:27017/blogapp' ,{useUnifiedTopology: true,useNewUrlParser: true}).catch(error => handleError(error));


//mongoose config

var blogschema =mongoose.Schema({
    title:String,
    image:String,
    body:String,
},{timestamps:true});

var blog =mongoose.model("blog",blogschema);
//restful route
//index route
app.get("/blogs",(req,res) =>{
    blog.find({},(err,blog) =>{
    if(err)
    { 
        console.log("err")
    }
    else{
        res.render("index",{blog:blog})

    }
    });
    
})
app.get("/",(req,res) =>{
    res.redirect("/blogs");
})
app.get("/a",(req,res) =>{
    res.send("hello");
})


//new route
app.get("/blogs/new",(req,res)=>
{
res.render("new");
})
//create route

app.post("/blogs",(req,res) =>{
    //create blogs
    blog.create(req.body.blog,function(err,blogpost){
        if(err){
            res.render("new");
        }
        else{
            res.redirect("/blogs");
        }
    });
});
//show route
app.get("/blogs/:id",(req,res)=>{
     blog.findById(req.params.id,(err,foundblog)=>{
    if(err){
        console.log("error found");
    }
    else{
        res.render("show",{blogs:foundblog})
    }
     });
});

//edit route

app.get("/blogs/:id/edit",(req,res)=>{
    blog.findById(req.params.id,(err,editdata)=>{
        res.render("edit",{editdata:editdata});
    })
})

//update
app.put("/blogs/:id",(req,res)=>{
blog.findByIdAndUpdate(req.params.id,req.body.blog,(err,updatedblog)=>{
    if(err){
        console.log("err");
    }
    else{
        res.redirect("/blogs/"+req.params.id);
    }
})
})
//destroy
app.delete("/blogs/:id",(req,res)=>{
 blog.findByIdAndDelete(req.params.id,(err)=>{
     if(err){
         res.redirect("/blogs");
     }
     else{
        return res.redirect("/blogs");
     }
 })
});






app.listen(process.env.PORT||8000,()=>{
    console.log("server is connected");
})
  
